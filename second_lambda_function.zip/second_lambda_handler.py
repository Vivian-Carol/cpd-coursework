import boto3
import json

def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('VehicleTable-Otuoma-Caroline-s2110913')
    sns = boto3.client('sns')
    topic_arn = 'arn:aws:sns:us-east-1:105310011039:VehicleNotificationTopic'
    
    for record in event['Records']:
        if record['eventName'] == 'INSERT':
            new_image = record['dynamodb']['NewImage']
            vehicle_id = new_image['VehicleID']['S']
            
            # Check if the vehicle is blacklisted
            response = table.get_item(Key={'VehicleId': vehicle_id})
            item = response['Item']
            
            if item and item['Status'] == 'Blacklisted':
                # Send an email notification
                message = f"Vehicle {vehicle_id} is blacklisted."
                sns.publish(TopicArn=topic_arn, Message=message)
    
    return {
        'statusCode': 200,
        'body': json.dumps('Notification sent if vehicle is blacklisted.')
    }
